SAVA AUTOMOBILE Android starter project

This is an Android Studio / GitHub Actions project source, not a compiled APK.
To build:
1. Upload this project to a GitHub repository (include hidden .github folder).
2. Open the repository's Actions tab.
3. Run 'Build SAVA APK' workflow (or push to main).
4. Download the SAVA-Automobile-APK artifact and install app-debug.apk on Android.

App:
- Google ML Kit barcode scanning UI (requires Google Play services).
- Product registration for first-time barcode.
- Quantity-based stock addition in whole pieces.
- Local SQLite storage on this phone.
- No computer sync / cloud backup in this starter build.

For production distribution, create a signed release APK and test on the target phone.
