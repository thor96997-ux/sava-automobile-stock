package com.sava.automobile

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface

class StockDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "sava_stock.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE products (
            barcode TEXT PRIMARY KEY, name TEXT NOT NULL, brand TEXT, model TEXT, rack TEXT,
            qty INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT, qty INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    data class Product(val barcode:String,val name:String,val brand:String,val model:String,val rack:String,val qty:Int)
    fun get(code:String): Product? {
        readableDatabase.rawQuery("SELECT barcode,name,brand,model,rack,qty FROM products WHERE barcode=?", arrayOf(code)).use {
            if (!it.moveToFirst()) return null
            return Product(it.getString(0),it.getString(1),it.getString(2) ?: "",it.getString(3) ?: "",it.getString(4) ?: "",it.getInt(5))
        }
    }
    fun addProduct(code:String,name:String,brand:String,model:String,rack:String,qty:Int) {
        val v=ContentValues().apply { put("barcode",code);put("name",name);put("brand",brand);put("model",model);put("rack",rack);put("qty",qty) }
        writableDatabase.insertOrThrow("products",null,v)
        if(qty>0) movement(code,qty)
    }
    fun addStock(code:String,qty:Int) {
        writableDatabase.execSQL("UPDATE products SET qty=qty+? WHERE barcode=?", arrayOf(qty,code))
        movement(code,qty)
    }
    private fun movement(code:String,qty:Int) {
        val v=ContentValues().apply { put("barcode",code);put("qty",qty) }
        writableDatabase.insert("movements",null,v)
    }
    fun totals(): Pair<Int,Int> {
        readableDatabase.rawQuery("SELECT COUNT(*),COALESCE(SUM(qty),0) FROM products",null).use {
            it.moveToFirst(); return Pair(it.getInt(0),it.getInt(1))
        }
    }
}

class MainActivity : Activity() {
    private lateinit var db: StockDb
    private lateinit var status: TextView
    private lateinit var summary: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=StockDb(this)
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,36,28,24); setBackgroundColor(0xFFF3F4F6.toInt()) }
        val title=TextView(this).apply { text="SAVA AUTOMOBILE";textSize=24f;typeface=Typeface.DEFAULT_BOLD;setTextColor(0xFF111827.toInt()) }
        val sub=TextView(this).apply { text="STOCK SCANNER";textSize=14f;setTextColor(0xFF64748B.toInt()); setPadding(0,4,0,22) }
        val scan=Button(this).apply { text="SCAN BARCODE";setOnClickListener { startScan() } }
        status=TextView(this).apply { text="Scan a product barcode to begin.";textSize=15f;setPadding(0,18,0,18) }
        summary=TextView(this).apply { textSize=14f;setPadding(0,20,0,12) }
        val backup=TextView(this).apply { text="Stock is saved on this phone.";textSize=12f;setTextColor(0xFF64748B.toInt()) }
        layout.addView(title);layout.addView(sub);layout.addView(scan);layout.addView(status);layout.addView(summary);layout.addView(backup)
        setContentView(ScrollView(this).apply { addView(layout) })
        updateSummary()
    }
    private fun startScan() {
        val options=GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(com.google.mlkit.vision.barcode.common.Barcode.FORMAT_ALL_FORMATS)
            .enableAutoZoom()
            .build()
        GmsBarcodeScanning.getClient(this,options).startScan()
            .addOnSuccessListener { barcode ->
                val code=barcode.rawValue
                if(!code.isNullOrBlank()) handleBarcode(code)
                else status.text="Barcode read nahi ho paya. Dobara scan karein."
            }
            .addOnCanceledListener { status.text="Scan cancel kiya gaya." }
            .addOnFailureListener { status.text="Scanner start nahi hua. Google Play services update karein." }
    }
    private fun handleBarcode(code:String) {
        val p=db.get(code)
        if(p!=null) showAddStock(p) else showNewProduct(code)
    }
    private fun showAddStock(p:StockDb.Product) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(24,18,24,18) }
        box.addView(TextView(this).apply { text="${p.name}\nBarcode: ${p.barcode}\nBrand: ${p.brand.ifBlank{"-"}}\nModel: ${p.model.ifBlank{"-"}}\nRack: ${p.rack.ifBlank{"-"}}\nCurrent stock: ${p.qty} pieces";textSize=16f })
        val qty=EditText(this).apply { hint="Quantity to add (pieces)";inputType=android.text.InputType.TYPE_CLASS_NUMBER }
        box.addView(qty)
        AlertDialogBuilder(this).show("Add Stock",box,"ADD") {
            val n=qty.text.toString().toIntOrNull()
            if(n==null || n<1) { status.text="Valid quantity enter karein."; return@show }
            db.addStock(p.barcode,n);status.text="$n pieces added to ${p.name}.";updateSummary()
        }
    }
    private fun showNewProduct(code:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8) }
        fun field(hint:String, number:Boolean=false):EditText {
            val e=EditText(this).apply { this.hint=hint }
            if(number)e.inputType=android.text.InputType.TYPE_CLASS_NUMBER
            box.addView(e);return e
        }
        box.addView(TextView(this).apply { text="New barcode: $code";textSize=14f })
        val name=field("Product name *");val brand=field("Brand / Company");val model=field("Vehicle model");val rack=field("Rack number");val qty=field("Opening stock (pieces)",true)
        AlertDialogBuilder(this).show("Register Product",box,"SAVE") {
            val n=qty.text.toString().toIntOrNull() ?: 0
            if(name.text.toString().isBlank() || n<0){status.text="Product name aur valid quantity zaroori hai.";return@show}
            try { db.addProduct(code,name.text.toString().trim(),brand.text.toString(),model.text.toString(),rack.text.toString(),n);status.text="Product saved.";updateSummary() }
            catch(e:Exception){status.text="Product save nahi hua: ${e.message}"}
        }
    }
    private fun updateSummary(){ val t=db.totals();summary.text="Total products: ${t.first}\nTotal pieces: ${t.second}" }
}
