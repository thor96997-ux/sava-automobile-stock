package com.sava.automobile
import android.content.Context
import android.app.AlertDialog
class AlertDialogBuilder(private val context:Context) {
    fun show(title:String, view:android.view.View, positive:String, onPositive:()->Unit) {
        AlertDialog.Builder(context).setTitle(title).setView(view).setPositiveButton(positive) { _,_ -> onPositive() }.setNegativeButton("CANCEL",null).show()
    }
}
